//___FILEHEADER___

import Testing
@testable import ___VARIABLE_productName:identifier___

struct ___FILEBASENAME:identifier___ {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
