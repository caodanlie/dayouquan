import Foundation

class ArticleViewModel: ObservableObject {
    @Published var selectedTab = 0
    @Published var articles: [Article] = []
    
    let tabs = ["热门线报"]
    
    init() {
        // 模拟数据
        articles = [
            Article(number: 1, title: "拜年，你选线上还是线下？", tag: .hot),
            Article(number: 2, title: "贺岁舞剧《过年》美国首演", tag: .hot),
            Article(number: 3, title: "四风新苗头一场不喝二场喝", tag: .new),
            Article(number: 5, title: "英伟达平台上线DeepSeek", tag: .hot),
            Article(number: 6, title: "中东部地区迎较大范围雨雪", tag: .hot),
            Article(number: 7, title: "封神第二部：还好有邓婵玉", tag: .new),
            Article(number: 8, title: "谁是下一任国奥委会主席", tag: .new),
            Article(number: 9, title: "大年初二迎来出游峰值", tag: .hot),
        ]
    }
}
