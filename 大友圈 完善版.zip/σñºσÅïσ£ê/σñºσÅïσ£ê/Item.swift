//
//  Item.swift
//  大友圈
//
//  Created by pc2025 on 2025/2/1.
//

import Foundation
import SwiftData

@Model
final class Item {
    var timestamp: Date
    
    init(timestamp: Date) {
        self.timestamp = timestamp
    }
}
