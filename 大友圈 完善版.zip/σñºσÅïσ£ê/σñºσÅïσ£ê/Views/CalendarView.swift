import SwiftUI

struct CategoryItem: Identifiable {
    let id = UUID()
    let icon: String
    let title: String
    let subtitle: String
}

struct CalendarView: View {
    let categories: [CategoryItem] = [
        CategoryItem(icon: "phone.fill", title: "话费&流量", subtitle: "话费充值,流量充值"),
        CategoryItem(icon: "wifi", title: "领流量", subtitle: "签到领流量,强卡领流量"),
        CategoryItem(icon: "tv.fill", title: "视频娱乐", subtitle: "爱奇艺,优酷,映客充值"),
        CategoryItem(icon: "fuelpump.fill", title: "加油卡", subtitle: "中石油,中石化,北京壳牌"),
        CategoryItem(icon: "drop.fill", title: "生活缴费", subtitle: "水电,燃气,话费等"),
        CategoryItem(icon: "giftcard.fill", title: "App Store 充值卡", subtitle: "App Store,充值卡"),
        CategoryItem(icon: "gamecontroller.fill", title: "QQ&游戏", subtitle: "QQ充值,游戏充值"),
        CategoryItem(icon: "mappin.circle.fill", title: "本地生活", subtitle: "家政保洁,婚纱摄影"),
        CategoryItem(icon: "person.crop.circle.fill", title: "宽带靓号", subtitle: "宽带新装,宽带续约"),
        CategoryItem(icon: "ticket.fill", title: "乐园门票", subtitle: "游乐园,景区门票"),
        CategoryItem(icon: "film.fill", title: "电影演出", subtitle: "电影,选座"),
        CategoryItem(icon: "cross.case.fill", title: "看病挂号", subtitle: "名医问诊,三甲挂号"),
        CategoryItem(icon: "display", title: "网费充值", subtitle: "网吧,会员卡"),
        CategoryItem(icon: "theatermasks.fill", title: "演出票", subtitle: "演唱会,话剧"),
        CategoryItem(icon: "airplane", title: "国际漫游", subtitle: "国际WiFi,专享"),
        CategoryItem(icon: "cart.fill", title: "京东网厅", subtitle: "合约机,换套餐,免费领取")
    ]
    
    let columns: [GridItem] = Array(repeating: .init(.flexible()), count: 2)
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                Text("全部分类")
                    .font(.system(size: 18, weight: .medium))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                
                LazyVGrid(columns: columns, spacing: 12) {
                    ForEach(categories) { item in
                        VStack(alignment: .leading, spacing: 4) {
                            HStack(spacing: 8) {
                                Image(systemName: item.icon)
                                    .font(.system(size: 16))
                                    .foregroundColor(.blue)
                                    .frame(width: 24, height: 24)
                                
                                Text(item.title)
                                    .font(.system(size: 15))
                                    .foregroundColor(.primary)
                            }
                            
                            Text(item.subtitle)
                                .font(.system(size: 12))
                                .foregroundColor(.secondary)
                                .lineLimit(1)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color(UIColor.systemBackground))
                        .cornerRadius(12)
                        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
                    }
                }
                .padding(.horizontal, 12)
            }
        }
        .background(Color(UIColor.systemGroupedBackground))
    }
}

#Preview {
    CalendarView()
}