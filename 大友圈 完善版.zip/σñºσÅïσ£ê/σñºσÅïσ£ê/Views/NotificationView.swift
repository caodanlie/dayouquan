import SwiftUI

struct NotificationView: View {
    @State private var showNotificationBanner = true
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                if showNotificationBanner {
                    HStack {
                        Image(systemName: "exclamationmark.triangle")
                            .foregroundColor(.orange)
                        Text("推送通知未开启，会错过重要消息哦。")
                            .font(.system(size: 14))
                        Spacer()
                        Button(action: {
                            showNotificationBanner = false
                        }) {
                            Text("去开启")
                                .font(.system(size: 14))
                                .foregroundColor(.orange)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                    .background(Color(UIColor.systemBackground))
                }
                
                ScrollView {
                    LazyVStack(spacing: 12) {
                        MessageSection(title: "系统消息", icon: "bell.fill", iconColor: .purple, time: "11-30 17:00", message: "欢迎您注册大友圈，请牢记你的账号请勿泄漏给他人！")
                        
                        MessageSection(title: "活动消息", icon: "gift.fill", iconColor: .red, count: 99, time: "2022-04-26", message: "本周会不定时开放一批大友圈测试用户...")
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 12)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("消息中心")
                        .font(.system(size: 17, weight: .medium))
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        // 全部已读功能
                    }) {
                        Text("全部已读")
                            .font(.system(size: 14))
                            .foregroundColor(.blue)
                    }
                }
            }
        }
    }
}

#Preview {
    NotificationView()
}