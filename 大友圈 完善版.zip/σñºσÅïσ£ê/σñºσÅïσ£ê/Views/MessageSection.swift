import SwiftUI

struct MessageSection: View {
    let title: String
    let icon: String
    let iconColor: Color
    var count: Int? = nil
    let time: String
    let message: String
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Image(systemName: icon)
                    .font(.system(size: 18))
                    .foregroundColor(iconColor)
                Text(title)
                    .font(.system(size: 16, weight: .medium))
                Spacer()
                if let count = count {
                    Text("\(count)")
                        .font(.system(size: 12))
                        .foregroundColor(.white)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.red)
                        .clipShape(Capsule())
                }
                Text(time)
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            
            Divider()
                .padding(.leading, 16)
            
            HStack {
                Text(message)
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
                    .lineLimit(1)
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
        }
        .background(Color(UIColor.systemBackground))
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.1), radius: 5)
    }
}

#Preview {
    MessageSection(
        title: "系统消息",
        icon: "bell.fill",
        iconColor: .purple,
        count: 3,
        time: "昨天 17:00",
        message: "这是一条系统消息的预览内容..."
    )
    .padding()
    .background(Color(red: 0.95, green: 0.95, blue: 0.97))
}