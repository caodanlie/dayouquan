import SwiftUI

struct VideoView: View {
    @Environment(\.colorScheme) private var colorScheme
    @AppStorage("isDarkMode") private var isDarkMode = false
    
    var body: some View {
        ScrollView {
            VStack {
            VStack(spacing: 16) {
                // 用户信息卡片
                VStack(spacing: 12) {
                    HStack {
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .frame(width: 60, height: 60)
                            .clipShape(Circle())
                            .foregroundColor(.gray)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text("大大")
                                    .font(.system(size: 18, weight: .medium))
                                Text("Lv3")
                                    .font(.system(size: 12))
                                    .foregroundColor(.orange)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color.orange.opacity(0.2))
                                    .cornerRadius(8)
                            }
                            Text("ID：16717")
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                        }
                        Spacer()
                    }
                    
                    HStack(spacing: 30) {
                        StatView(title: "我的关注", value: "2")
                        StatView(title: "我的收藏", value: "19")
                        StatView(title: "我的帖子", value: "130")
                    }
                }
                .padding(16)
                .background(Color(UIColor.systemBackground))
                .cornerRadius(12)
                .shadow(color: Color.black.opacity(0.1), radius: 5)
                
                // 签到区域
                HStack {
                    Image(systemName: "crown.fill")
                        .foregroundColor(.yellow)
                    Text("每日签到")
                        .font(.system(size: 16, weight: .medium))
                    Spacer()
                    Text("坚持签到获得更多特权")
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                    Image(systemName: "chevron.right")
                        .foregroundColor(.gray)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color(UIColor.systemBackground))
                .cornerRadius(12)
                .shadow(color: Color.black.opacity(0.1), radius: 5)
                
                // 活动中心和奖品中心
                HStack(spacing: 12) {
                    ActivityCard(icon: "gift.fill", title: "任务中心", subtitle: "做任务升级权限", color: .pink)
                    ActivityCard(icon: "star.fill", title: "兑换中心", subtitle: "兑换实物视频vip会员", color: .blue)
                }
                
                // 常用推荐功能列表
                VStack(spacing: 0) {
                    Text("常用功能")
                        .font(.system(size: 16, weight: .medium))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                    
                    Divider()
                    
                    FunctionRow(icon: "arrow.counterclockwise", title: "账号设置", showTag: true)
                    Divider().padding(.leading, 40)
                    FunctionRow(icon: "eye.slash", title: "修改密码")
                    Divider().padding(.leading, 40)
                    FunctionRow(icon: "magnifyingglass", title: "设置邮箱")
                    Divider().padding(.leading, 40)
                    Button(action: {
                        isDarkMode.toggle()
                        setAppearance(isDarkMode)
                    }) {
                        FunctionRow(icon: "moon.fill", title: "暗黑模式", showToggle: true, isToggleOn: $isDarkMode)
                    }
                    Divider().padding(.leading, 40)
                    FunctionRow(icon: "xmark.shield", title: "退出登录")
                }
                .background(Color(UIColor.systemBackground))
                .cornerRadius(12)
                .shadow(color: Color.black.opacity(0.1), radius: 5)
                
                // 其他功能列表
                VStack(spacing: 0) {
                    Text("其他")
                        .font(.system(size: 16, weight: .medium))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                    
                    Divider()
                    
                    FunctionRow(icon: "gearshape", title: "设置")
                    Divider().padding(.leading, 40)
                    FunctionRow(icon: "exclamationmark.bubble", title: "意见反馈")
                    Divider().padding(.leading, 40)
                    FunctionRow(icon: "info.circle", title: "关于我们")
                    Divider().padding(.leading, 40)
                    FunctionRow(icon: "creditcard", title: "联系我们")
                }
                .background(Color(UIColor.systemBackground))
                .cornerRadius(12)
                .shadow(color: Color.black.opacity(0.1), radius: 5)
                
                // 背景商城
                HStack {
                    Image(systemName: "bag.fill")
                        .foregroundColor(.purple)
                    Text("意向合作")
                        .font(.system(size: 16, weight: .medium))
                    Spacer()
                    Text("诚心交友，创建大友圈！")
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                    Image(systemName: "chevron.right")
                        .foregroundColor(.gray)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color(UIColor.systemBackground))
                .cornerRadius(12)
                .shadow(color: Color.black.opacity(0.1), radius: 5)
            }
            .padding(16)
        }
        }
    }
    
    private func setAppearance(_ isDark: Bool) {
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            windowScene.windows.forEach { window in
                window.overrideUserInterfaceStyle = isDark ? .dark : .light
            }
        }
    }
}

struct StatView: View {
    let title: String
    let value: String
    
    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 16, weight: .medium))
            Text(title)
                .font(.system(size: 12))
                .foregroundColor(.gray)
        }
    }
}

struct ActivityCard: View {
    let icon: String
    let title: String
    let subtitle: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: icon)
                .foregroundColor(color)
                .font(.system(size: 24))
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 16, weight: .medium))
                Text(subtitle)
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.1), radius: 5)
    }
}

struct FunctionRow: View {
    let icon: String
    let title: String
    var showTag: Bool = false
    var showToggle: Bool = false
    @Binding var isToggleOn: Bool
    
    init(icon: String, title: String, showTag: Bool = false, showToggle: Bool = false, isToggleOn: Binding<Bool>? = nil) {
        self.icon = icon
        self.title = title
        self.showTag = showTag
        self.showToggle = showToggle
        self._isToggleOn = isToggleOn ?? .constant(false)
    }
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.system(size: 18))
                .foregroundColor(.gray)
                .frame(width: 24)
            Text(title)
                .font(.system(size: 16))
            if showTag {
                Text("限免")
                    .font(.system(size: 12))
                    .foregroundColor(.red)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Color.red.opacity(0.1))
                    .cornerRadius(8)
            }
            Spacer()
            if showToggle {
                Toggle("", isOn: $isToggleOn)
                    .labelsHidden()
            } else {
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}

#Preview {
    VideoView()
}