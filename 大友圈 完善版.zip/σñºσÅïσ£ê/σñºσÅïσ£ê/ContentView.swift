import SwiftUI
import SwiftData

struct ContentView: View {
    @State private var selectedTab = 0
    
    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $selectedTab) {
                HomeView()
                    .tag(0)
                CalendarView()
                    .tag(1)
                Text("")
                    .tag(2)
                NotificationView()
                    .tag(3)
                VideoView()
                    .tag(4)
            }
            
            HStack(spacing: 0) {
                ForEach(0..<5) { index in
                    if index == 2 {
                        AddButton()
                            .offset(y: -25)
                            .frame(width: 60)
                    } else {
                        TabBarItem(
                            icon: getIcon(for: index),
                            title: getTitle(for: index),
                            isSelected: selectedTab == index
                        )
                        .onTapGesture {
                            selectedTab = index
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(
                CustomTabBarShape()
                    .fill(Color(UIColor.systemBackground))
            )
            .shadow(color: Color.black.opacity(0.15), radius: 8, x: 0, y: -3)
            .padding(.horizontal)
        }
    }
    
    private func getIcon(for index: Int) -> String {
        switch index {
        case 0: return "house.fill"
        case 1: return "list.bullet.rectangle.fill"
        case 3: return "bell.fill"
        case 4: return "person.fill"
        default: return ""
        }
    }
    
    private func getTitle(for index: Int) -> String {
        switch index {
        case 0: return "首页"
        case 1: return "圈类"
        case 3: return "通知"
        case 4: return "我的"
        default: return ""
        }
    }
}

struct TabBarItem: View {
    let icon: String
    let title: String
    let isSelected: Bool
    
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 26, weight: .bold))
            Text(title)
                .font(.system(size: 13, weight: .semibold))
                .shadow(color: .black.opacity(0.2), radius: 1, x: 0, y: 1)
        }
        .foregroundColor(isSelected ? .blue : .gray)
    }
}

struct AddButton: View {
    var body: some View {
        Button(action: {
            // 添加按钮的点击事件
        }) {
            ZStack {
                Circle()
                    .fill(Color.blue)
                    .frame(width: 55, height: 55)
                    .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 2)
                
                Image(systemName: "plus")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(.white)
            }
        }
    }
}

struct CustomTabBarShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        let centerWidth: CGFloat = 60
        let centerHeight: CGFloat = 30
        let cornerRadius: CGFloat = 25
        
        // 左侧部分
        path.move(to: CGPoint(x: 0, y: cornerRadius))
        path.addArc(center: CGPoint(x: cornerRadius, y: cornerRadius),
                    radius: cornerRadius,
                    startAngle: .degrees(180),
                    endAngle: .degrees(270),
                    clockwise: false)
        
        path.addLine(to: CGPoint(x: (rect.width - centerWidth) / 2, y: 0))
        
        // 中间凹槽
        path.addCurve(to: CGPoint(x: rect.width / 2, y: centerHeight),
                      control1: CGPoint(x: (rect.width - centerWidth) / 2 + centerWidth * 0.4, y: 0),
                      control2: CGPoint(x: rect.width / 2 - centerWidth * 0.3, y: centerHeight))
        
        path.addCurve(to: CGPoint(x: (rect.width + centerWidth) / 2, y: 0),
                      control1: CGPoint(x: rect.width / 2 + centerWidth * 0.3, y: centerHeight),
                      control2: CGPoint(x: (rect.width + centerWidth) / 2 - centerWidth * 0.4, y: 0))
        
        // 右侧部分
        path.addLine(to: CGPoint(x: rect.width - cornerRadius, y: 0))
        path.addArc(center: CGPoint(x: rect.width - cornerRadius, y: cornerRadius),
                    radius: cornerRadius,
                    startAngle: .degrees(270),
                    endAngle: .degrees(0),
                    clockwise: false)
        
        path.addLine(to: CGPoint(x: rect.width, y: rect.height - cornerRadius))
        path.addArc(center: CGPoint(x: rect.width - cornerRadius, y: rect.height - cornerRadius),
                    radius: cornerRadius,
                    startAngle: .degrees(0),
                    endAngle: .degrees(90),
                    clockwise: false)
        
        path.addLine(to: CGPoint(x: cornerRadius, y: rect.height))
        path.addArc(center: CGPoint(x: cornerRadius, y: rect.height - cornerRadius),
                    radius: cornerRadius,
                    startAngle: .degrees(90),
                    endAngle: .degrees(180),
                    clockwise: false)
        path.closeSubpath()
        
        return path
    }
}

// 占位视图
struct HomeView: View {
    @StateObject private var viewModel = ArticleViewModel()
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(spacing: 0) {
            // 顶部分类标签栏
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 20) {
                    ForEach(viewModel.tabs.indices, id: \.self) { index in
                        VStack(spacing: 6) {
                            HStack(spacing: 4) {
                                Image(systemName: getTabIcon(index))
                                    .font(.system(size: 13))
                                    .foregroundColor(viewModel.selectedTab == index ? .primary : .secondary)
                                Text(viewModel.tabs[index])
                                    .font(.system(size: 15, weight: viewModel.selectedTab == index ? .semibold : .regular))
                                    .foregroundColor(viewModel.selectedTab == index ? .primary : .secondary)
                            }
                            .frame(maxWidth: .infinity, alignment: .center)
                        
                            Rectangle()
                                .fill(viewModel.selectedTab == index ? Color.blue : Color.clear)
                                .frame(height: 2)
                        }
                        .onTapGesture {
                            withAnimation {
                                viewModel.selectedTab = index
                            }
                        }
                    }
                }
            }
            .padding(.horizontal)
            .padding(.top, 8)
            
            ScrollView {
                VStack(spacing: 12) {
                    ForEach(viewModel.articles) { article in
                        HStack(alignment: .center, spacing: 12) {
                            Text("\(article.number)")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(.blue)
                                .frame(width: 30)
                            
                            Text(article.title)
                                .font(.system(size: 16))
                                .lineLimit(2)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            Text(article.tag.rawValue)
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.white)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(article.tag == .hot ? Color.red.opacity(0.8) : Color.blue.opacity(0.8))
                                .cornerRadius(4)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        .background(colorScheme == .dark ? Color.black : Color.white)
                        .cornerRadius(12)
                        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
                        .padding(.horizontal)
                    }
                }
                .padding(.vertical, 12)
            }
        }
    }
}

private func getTabIcon(_ index: Int) -> String {
    if index == 0 {
        return "flame.fill"
    } else if index == 6 {
        return "magnifyingglass"
    } else {
        return "questionmark.circle.fill"
    }
}

#Preview {
    ContentView()
}
