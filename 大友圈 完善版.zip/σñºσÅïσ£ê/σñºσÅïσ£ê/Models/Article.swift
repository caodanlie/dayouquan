import Foundation

enum ArticleTag: String {
    case hot = "热门"
    case new = "最新"
}

struct Article: Identifiable {
    let id = UUID()
    let number: Int
    let title: String
    let tag: ArticleTag
}